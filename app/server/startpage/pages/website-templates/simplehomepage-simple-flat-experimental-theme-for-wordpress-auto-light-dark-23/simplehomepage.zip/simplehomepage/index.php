<?php
get_header();
//<!-- page: index.php (fornt-page.php) -->
?>

<?php
/*
if (have_posts()){
while (have_posts()){
the_post();
the_content();
}
}*/

if (!is_page()){
echo '<h1 class="op tCenter">Blog</h1>';
}

//https://stackoverflow.com/questions/69542331/display-custom-posts-in-custom-template-in-wordpress
if (have_posts()){
while (have_posts()) {
the_post(); 

//<div>'.apply_filters('get_the_excerpt', get_the_excerpt()).'</div>
//<div class="featured-image">'.the_post_thumbnail().'</div>
//<div>'.apply_filters('the_content', get_the_content()).'</div>
//wpdocs_show_tags()
/*<div id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>*/
echo '<div class="bgList border3List borderRadius2 tLeft">';
/*<?php post_class(); ?>
<div id="post-<?php the_ID(); ?>" <?php post_class( 'class-name' ); ?>>*/
?>
<div id="post-<?php the_ID(); ?>" <?php post_class( 'class-name' ); ?>>
<?php
echo '<h2><a href="'.get_permalink().'">'.get_the_title().'</a></h2>';
?>
<!--https://wordpress.stackexchange.com/questions/57476/display-post-thumbnail-without-being-featured-image#-->
<div id="image-wrap">
<?php 
if ( has_post_thumbnail() ) {
the_post_thumbnail();
} 
?>
</div><!--end image-wrap-->
<?php
echo apply_filters('the_content', get_the_content())
?>
</div>
<div class="postFooter break2 small clear padding3 notUnderline">
<span class="tagList tLeft left"><?php echo the_category( ', ' ).the_tags('<span> / ', ', ', '</span>'); ?></span>
<span class="tagList tRight right">
<?php
if (!is_page()){
//https://stackoverflow.com/questions/4290420/wordpress-how-to-check-whether-it-is-post-or-page
echo '<a class="block tRight" href="'.get_permalink().'">'.get_the_date().' ('.get_comments_number().')</a>';
} else {
echo '<a class="block tRight"></a>';
}
?>
</span>
</div>

<?php
echo '</div>';

}
}
?>

<?php
//<!-- archive search front-page index -->
?>
<div class="padding margin"></div>

<nav>
<div class="wrapper2">
<div class="tCenter balance notUnderline">
<?php
the_posts_pagination();
?>
</div>
</div>
</nav>


<?php
if (!is_page()){
?>
<div class="margin2 padding2"></div>
<div class="op tCenter small padding2">list of tags:</div>
<div class="center">
<div class="tagList">
<?php wp_tag_cloud( array(
   'smallest' => 8, // size of least used tag
   'largest'  => 22, // size of most used tag
   'unit'     => 'px', // unit for sizing the tags
   'number'   => 45, // displays at most 45 tags
   'orderby'  => 'name', // order tags alphabetically
   'order'    => 'ASC', // order tags by ascending order
   'taxonomy' => 'post_tag' // you can even make tags for custom taxonomies
) );
?>
</div>
</div>

<div class="padding2 margin2"></div>

<div class="wrapperSmall">
<?php get_search_form(); ?>
</div>

<?php
}
?>

<div class="margin2 padding2"></div>



<?php get_footer(); ?>
