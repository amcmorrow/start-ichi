<!DOCTYPE html>
<?php
//get_the_title();
//get_bloginfo('description');
/*
<title><?php echo the_title(); ?></title>
*/
?>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">

<!--<meta name="description" content="">
<meta name="keywords" content="">-->

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--<link rel="icon" href="" type="image/png">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">-->

<!-- wp_head -->
<?php wp_head(); ?>
<!-- // wp_head -->

<noscript>
<link rel="stylesheet" type="text/css" href="<?php echo esc_url( home_url() ); ?>/wp-content/themes/themehome/assets/css/noscript.css">
</noscript>

</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- top -->


<?php if ( is_active_sidebar( 'simplehomepage-sidebar-1' ) ) : ?>
<div class="clear"></div>
<div class="wrapper2 tLeft">
<aside>
	<div id="simplehomepage-sidebar-1" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 'simplehomepage-sidebar-1' ); ?>
	</div><!-- #sidebar -->
</aside>
</div>
<div class="clear"></div>
<?php endif; ?>

<!-- Navigation HTML part v.1.0.1 -->
<header>
<div class="wrapper3">
<div class="margin2"></div>

<div id="topNav" class="topNav">
<nav>

<a class="inlineBlock padding brand" style="padding-left: 0;" href="<?php echo esc_url( home_url() ); ?>" title="<?php bloginfo('name'); ?>">
<?php
// logo
if (function_exists('the_custom_logo')){
if (!empty(wp_get_attachment_image_src(get_theme_mod('custom_logo'))[0])){
echo '<img class="logo2 reduceLight" src="'.wp_get_attachment_image_src(get_theme_mod('custom_logo'))[0].'" alt="logo" style="max-width: 26px;">';
} else {
echo 'Home';
}
} else {
echo "Home";
}
?>
</a>
<span id="navMenu" class="navMenu">
<!-- links in nav -->
<?php
if (function_exists('wp_nav_menu')){
wp_nav_menu(
array(
'menu' => 'primary',
'container' => '',
'theme_location' => 'primary',
'items_wrap' => '<ul>%3$s</ul>'
)
);
}
?>
<!-- // links in nav -->
</span>

<div class="dropdownMenuContentWrapper">
<div class="dropdownMenuContent">
<a id="dropdownMenuButton" class="dropdownMenuButton inlineBlock padding mClassNavUp brand borderBottomTransparent itemLinkAni" href="#" onclick="fuMDropdownButton();return false;">☰ Menu</a>

<div id="dropdownMenu" class="dropdownMenu">
<div class="dropdownMenuColumn shadow bg2 padding2 borderRadius2">
<!-- links for show in dropdown (duplicate) -->
<?php
wp_nav_menu(
array(
'menu' => 'primary',
'container' => '',
'theme_location' => 'primary',
'items_wrap' => '<ul>%3$s</ul>'
)
);
?>
<!-- // links for show in dropdown (duplicate) -->
</div>
</div>

</div>
</div>

<?php
/*
<!--
<form class="noscriptHide inlineBlock padding" style="padding-right: 0;" method="GET" action="<?php echo esc_url( home_url() ); ?>" role="search">
<input id="siteSearch" class="borderRadius3" type="search" placeholder="site search" name="s" autocomplete="off">
</form>-->
*/
?>

<?php echo get_search_form();?>

</nav>
</div>

</div>
</header>
<!-- // Navigation HTML -->



<?php
/*wp_nav_menu(
array(
'menu' => 'primary',
'container' => '',
'theme_location' => 'primary',
'items_wrap' => '<ul>%3$s</ul>'
)
);*/
?>
<!--<hr>-->
<!-- // top -->

<!-- content -->
<main class="content">
<div class="wrapper2">


<?php
//echo get_the_title();
?>



