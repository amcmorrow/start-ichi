<?php


function simplehomepage_theme_support(){
// Adds dynamic title tag support
add_theme_support("title-tag");
add_theme_support("custom-logo");
add_theme_support("post-thumbnails");
add_theme_support("automatic-feed-links");

add_theme_support("align-wide");
add_theme_support("responsive-embeds");

//add_theme_support( 'custom-background' );
//add_theme_support( 'custom-header' );
add_theme_support("wp-block-styles");

add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'style', 'script' ) );
}

add_action('after_setup_theme','simplehomepage_theme_support');


//https://developer.wordpress.org/reference/functions/add_editor_style/
/**
 * Registers an editor stylesheet for the theme.
 */

function simplehomepage_theme_add_editor_styles() {
add_editor_style( 'editor-style.css' );
}
add_action( 'admin_init', 'simplehomepage_theme_add_editor_styles' );



function simplehomepage_menus(){
$locations = array(
'primary' => "Desktop Primary Menu",
//'footer' => "Footer Menu Items"
);

register_nav_menus($locations);
}

add_action('init', 'simplehomepage_menus');


function simplehomepage_register_styles(){

//$simplehomepage_varsion = wp_get_theme()->get('Version');
//wp_enqueue_style('main', get_template_directory_uri()."/assets/css/main.css",  array(), '1.0.0', 'all');
wp_enqueue_style('main', get_template_directory_uri()."/assets/css/main.css",  false, '1.0.0', 'all');
wp_enqueue_style('auto', get_template_directory_uri()."/assets/css/auto.css",  false, '1.0.0', 'all');
wp_enqueue_style('style', get_template_directory_uri()."/style.css",  false, '1.0.0', 'all');
}

add_action('wp_enqueue_scripts', 'simplehomepage_register_styles');


function simplehomepage_register_scripts(){
wp_enqueue_script('main', get_template_directory_uri()."/assets/js/main.js",  array(), '1.0.0', 'all');
}

add_action('wp_enqueue_scripts', 'simplehomepage_register_scripts');






/*
function simplehomepage_widget_areas(){

register_sidebar(
array(
'before_title' => '',
'after_title' => '',
'before_widget' => '',
'after_widget' => '',
),
array(
'name' => 'Sidebar Area',
'id' => 'sidebar-1',
'description' => 'Sidebar Widget Area',
)
);
}

add_action('widgets_init', 'simplehomepage_widget_areas');
*/



/**
 * Add a sidebar.
 */
//https://developer.wordpress.org/reference/functions/register_sidebar/
// Top Sidebar
function simplehomepage_widgets_init() {
	register_sidebar( array(
//		'name'          => __( 'Main Sidebar', 'textdomain' ),
		'name'          => 'Top Sidebar',
		'id'            => 'simplehomepage-sidebar-1',
//		'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
		'description'   => 'Widgets in this area will be shown on all posts and pages.',
//		'before_widget' => '<li id="%1$s" class="widget %2$s">',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
//		'after_widget'  => '</li>',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="widgettitle bold h2">',
		'after_title'   => '</div>',
	) );
}

add_action( 'widgets_init', 'simplehomepage_widgets_init' );

// Bottom Sidebar
function simplehomepage_widgets_init_2() {
	register_sidebar( array(
//		'name'          => __( 'Main Sidebar', 'textdomain' ),
		'name'          => 'Bottom Sidebar',
		'id'            => 'simplehomepage-sidebar-2',
//		'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
		'description'   => 'Widgets in this area will be shown on all posts and pages.',
//		'before_widget' => '<li id="%1$s" class="widget %2$s">',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
//		'after_widget'  => '</li>',
		'after_widget'  => '</div><div class="margin2 padding2"></div>',
		'before_title'  => '<h2 class="widgettitle">',
		'after_title'   => '</h2>',
	) );
}

add_action( 'widgets_init', 'simplehomepage_widgets_init_2' );


?>



