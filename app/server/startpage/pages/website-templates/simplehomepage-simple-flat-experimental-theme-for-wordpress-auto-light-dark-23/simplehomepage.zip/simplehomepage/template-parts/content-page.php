
<h1 class="op tCenter"><?php the_title(); ?></h1>

<?php
//https://codex.wordpress.org/Post_Thumbnails
if ( has_post_thumbnail() ) {
the_post_thumbnail();
}
?>
<?php

the_content();

//the_date();


?>


