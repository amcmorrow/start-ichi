
<?php
/*
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<h2><?php the_title(); ?></h2>
*/

?>

<h1 class="tCenter op"><?php the_title(); ?></h1>

<article>
<div class="bgList border3List borderRadius2 tLeft">
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
//https://codex.wordpress.org/Post_Thumbnails
if ( has_post_thumbnail() ) {
the_post_thumbnail();
}
?>
<?php
//the_excerpt();
the_content();
?>
</div>

<div class="postFooter break2 small clear padding3 notUnderline">
<span class="tagList tLeft left"><?php the_category( ', ' ).the_tags('<span> / ', ', ', '</span>'); ?></span>
<span class="tagList tRight right"><?php the_date(); echo " (".get_comments_number().")"; ?></span>
</div>

</div>
</article>





