<?php
get_header();
//<!-- page: archive.php -->
?>

<h1 class="op tCenter">Archive</h1>

<?php
if (have_posts()){
while (have_posts()){
echo is_page();
the_post();
//the_content();
get_template_part('template-parts/content', 'archive');
}
}
?>

<?php
//<!-- archive search front-page index -->
?>
<div class="padding margin"></div>

<nav>
<div class="wrapper2">
<div class="tCenter balance notUnderline">
<?php
the_posts_pagination();
?>
</div>
</div>
</nav>

<?php
if (!is_page()){
?>
<div class="margin2 padding2"></div>
<div class="op tCenter small padding2">Tag cloud:</div>
<div class="center">
<div class="tagList">
<?php wp_tag_cloud( array(
   'smallest' => 8, // size of least used tag
   'largest'  => 22, // size of most used tag
   'unit'     => 'px', // unit for sizing the tags
   'number'   => 45, // displays at most 45 tags
   'orderby'  => 'name', // order tags alphabetically
   'order'    => 'ASC', // order tags by ascending order
   'taxonomy' => 'post_tag' // you can even make tags for custom taxonomies
) );
?>
</div>
</div>

<div class="padding2 margin2"></div>

<div class="wrapperSmall">
<?php get_search_form(); ?>
</div>

<?php
}
?>

<div class="margin2 padding2"></div>

<?php
get_footer();
?>


