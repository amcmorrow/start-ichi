<?php
get_header();
//<!-- page: single.php -->
?>

<!--<h1 class="op tCenter">Post</h1>-->

<?php
if (have_posts()){
while (have_posts()){
the_post();
//the_content();
get_template_part('template-parts/content', 'article');
}
}
?>

<?php wp_link_pages(); ?>

<div class="margin padding"></div>

<div class="light border3List borderRadius2 notUnderline">
<div class="postFooter break2 small">
<span class="button tLeft left"><?php previous_post_link(); ?></span>
<span class="button tRight right"><?php next_post_link(); ?></span>
</div>
</div>

<div class="margin2 padding2"></div>

<?php
//comments_number();
comments_template();
?>

<?php
get_footer();
?>

