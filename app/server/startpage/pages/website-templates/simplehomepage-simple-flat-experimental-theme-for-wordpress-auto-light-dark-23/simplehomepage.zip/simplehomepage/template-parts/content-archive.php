
<?php
/*
the_post_thumbnail_url();
*/


/*
the_title();
the_excerpt();

the_date();
comments_number();
the_permalink();

comments_template();
*/

/*
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
*/
?>


<?php
echo is_page();
/*<?php post_class(); ?>
<div id="post-<?php the_ID(); ?>" <?php post_class( 'class-name' ); ?>>*/
//<div class="bgList border3List borderRadius2 tLeft ">

?>
<div class="bgList border3List borderRadius2 tLeft ">
<article>
<div id="post-<?php the_ID(); ?>" <?php post_class( 'class-name' ); ?>>
<h2><a href="<?php echo get_permalink()?>"><?php echo the_title(); ?></a></h2>
<?php
//https://codex.wordpress.org/Post_Thumbnails
if ( has_post_thumbnail() ) {
the_post_thumbnail();
}
?>
<?php
//the_excerpt();
the_content();
?>
</div>

<div class="postFooter break2 small clear padding3 notUnderline">
<span class="tagList tLeft left"><?php echo the_category( ', ' ).the_tags('<span> / ', ', ', '</span>'); ?></span>
<span class="tagList tRight right">
<?php
if (!is_page()){
//https://stackoverflow.com/questions/4290420/wordpress-how-to-check-whether-it-is-post-or-page
echo '<a class="block tRight" href="'.get_permalink().'">'.get_the_date().' ('.get_comments_number().')</a>';
} else {
echo '<a class="block tRight"></a>';
}
?>
</span>
</div>


</article>
</div>

<?php
/*<div class="padding smaller gray"><?php comments_number(); ?></div>*/
//comments_number();
//comments_template();
?>
