<?php
get_header();
//<!-- page: 404.php -->
?>

<h1 class="op tCenter orange">Page Not Found</h1>

<div class="margin2 padding2"></div>

<div class="wrapper">
<?php 
get_search_form();
?>
</div>

<?php
get_footer();
?>


